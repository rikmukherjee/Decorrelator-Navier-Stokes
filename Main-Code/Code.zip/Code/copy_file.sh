#!/bin/sh
\cp part.exe ../Data/Re2/Kappa1/Re_p1/
\cp part.exe ../Data/Re2/Kappa1/Re_p2/
\cp part.exe ../Data/Re2/Kappa2/Re_p1/
\cp part.exe ../Data/Re2/Kappa2/Re_p2/
\cp part.exe ../Data/Re2/Kappa3/Re_p1/
\cp part.exe ../Data/Re2/Kappa3/Re_p2/
